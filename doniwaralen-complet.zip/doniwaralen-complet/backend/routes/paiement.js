const express = require('express');
const router = express.Router();
const axios = require('axios');
const db = require('../config/db');
const { verifierToken } = require('../middleware/auth');

// ═══════════════════════════════════════════
// CONFIGURATION DES 3 SERVICES
// ═══════════════════════════════════════════

const CONFIG = {
  paydunya: {
    masterKey: process.env.PAYDUNYA_MASTER_KEY,
    privateKey: process.env.PAYDUNYA_PRIVATE_KEY,
    token: process.env.PAYDUNYA_TOKEN,
    mode: process.env.PAYDUNYA_MODE || 'test',
    baseUrl:
      process.env.PAYDUNYA_MODE === 'live'
        ? 'https://app.paydunya.com/api/v1'
        : 'https://app.paydunya.com/sandbox-api/v1',
  },
  wave: {
    apiKey: process.env.WAVE_API_KEY,
    baseUrl: 'https://api.wave.com/v1',
  },
  orangeMoney: {
    clientId: process.env.ORANGE_CLIENT_ID,
    clientSecret: process.env.ORANGE_CLIENT_SECRET,
    baseUrl: 'https://api.orange.com/orange-money-webpay/ml/v1',
  },
};

// ═══════════════════════════════════════════
// FONCTION UTILITAIRE — Récupérer montant
// ═══════════════════════════════════════════

async function getMontant(type, reference_id) {
  if (type === 'cours') {
    const [rows] = await db.promise().query('SELECT * FROM cours WHERE id = ?', [reference_id]);
    if (rows.length === 0) throw new Error('Cours introuvable.');
    if (rows[0].gratuit) throw new Error('Ce cours est gratuit !');
    return { montant: rows[0].prix, description: `Cours : ${rows[0].titre}` };
  } else if (type === 'livre') {
    const [rows] = await db.promise().query('SELECT * FROM livres WHERE id = ?', [reference_id]);
    if (rows.length === 0) throw new Error('Livre introuvable.');
    if (rows[0].prix === 0) throw new Error('Ce livre est gratuit !');
    return { montant: rows[0].prix, description: `Livre : ${rows[0].titre}` };
  }
  throw new Error('Type invalide.');
}

// ═══════════════════════════════════════════
// FONCTION — Activer accès après paiement
// ═══════════════════════════════════════════

async function activerAcces(utilisateur_id, type, reference_id) {
  if (type === 'cours') {
    await db.promise().query(
      'INSERT IGNORE INTO inscriptions (utilisateur_id, cours_id) VALUES (?, ?)',
      [utilisateur_id, reference_id]
    );
  }
}

// ═══════════════════════════════════════════
// 1️⃣  PAYDUNYA
// ═══════════════════════════════════════════

router.post('/paydunya/initier', verifierToken, async (req, res) => {
  const { type, reference_id } = req.body;

  try {
    const { montant, description } = await getMontant(type, reference_id);

    const headers = {
      'PAYDUNYA-MASTER-KEY': CONFIG.paydunya.masterKey,
      'PAYDUNYA-PRIVATE-KEY': CONFIG.paydunya.privateKey,
      'PAYDUNYA-TOKEN': CONFIG.paydunya.token,
      'Content-Type': 'application/json',
    };

    const factureData = {
      invoice: { total_amount: montant, description },
      store: {
        name: 'Doniwaralen',
        tagline: 'Lieu du Savoir',
        phone: '+223 00 00 00 00',
        website_url: process.env.FRONTEND_URL,
      },
      actions: {
        cancel_url: `${process.env.FRONTEND_URL}/paiement/annule`,
        return_url: `${process.env.FRONTEND_URL}/paiement/succes`,
        callback_url: `${process.env.BACKEND_URL}/api/paiement/paydunya/callback`,
      },
    };

    const response = await axios.post(
      `${CONFIG.paydunya.baseUrl}/checkout-invoice/create`,
      factureData,
      { headers }
    );

    if (response.data.response_code !== '00') {
      return res.status(400).json({ message: `❌ Erreur: ${response.data.response_text}` });
    }

    const token = response.data.token;

    await db.promise().query(
      'INSERT INTO paiements (utilisateur_id, montant, type, reference_id, methode, transaction_id) VALUES (?, ?, ?, ?, ?, ?)',
      [req.utilisateur.id, montant, type, reference_id, 'paydunya', token]
    );

    const url =
      CONFIG.paydunya.mode === 'live'
        ? `https://app.paydunya.com/checkout/invoice/${token}`
        : `https://app.paydunya.com/sandbox/checkout/invoice/${token}`;

    res.json({ message: '✅ Paiement initié !', url_paiement: url, token, montant });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Callback PayDunya
router.post('/paydunya/callback', async (req, res) => {
  const { data } = req.body;
  if (!data?.invoice_token) return res.status(400).json({ message: 'Données invalides.' });

  try {
    const headers = {
      'PAYDUNYA-MASTER-KEY': CONFIG.paydunya.masterKey,
      'PAYDUNYA-PRIVATE-KEY': CONFIG.paydunya.privateKey,
      'PAYDUNYA-TOKEN': CONFIG.paydunya.token,
    };

    const response = await axios.get(
      `${CONFIG.paydunya.baseUrl}/checkout-invoice/confirm/${data.invoice_token}`,
      { headers }
    );

    if (response.data.status === 'completed') {
      await db.promise().query(
        'UPDATE paiements SET statut = "confirme" WHERE transaction_id = ?',
        [data.invoice_token]
      );

      const [paiements] = await db.promise().query(
        'SELECT * FROM paiements WHERE transaction_id = ?',
        [data.invoice_token]
      );

      if (paiements.length > 0) {
        await activerAcces(paiements[0].utilisateur_id, paiements[0].type, paiements[0].reference_id);
      }

      res.json({ message: '✅ Paiement PayDunya confirmé !' });
    } else {
      await db.promise().query(
        'UPDATE paiements SET statut = "echoue" WHERE transaction_id = ?',
        [data.invoice_token]
      );
      res.json({ message: 'Paiement non complété.' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Erreur callback PayDunya.' });
  }
});

// ═══════════════════════════════════════════
// 2️⃣  WAVE
// ═══════════════════════════════════════════

router.post('/wave/initier', verifierToken, async (req, res) => {
  const { type, reference_id } = req.body;

  try {
    const { montant, description } = await getMontant(type, reference_id);

    const response = await axios.post(
      `${CONFIG.wave.baseUrl}/checkout/sessions`,
      {
        amount: montant.toString(),
        currency: 'XOF',
        error_url: `${process.env.FRONTEND_URL}/paiement/annule`,
        success_url: `${process.env.FRONTEND_URL}/paiement/succes`,
        client_reference: `${req.utilisateur.id}_${type}_${reference_id}`,
      },
      {
        headers: {
          Authorization: `Bearer ${CONFIG.wave.apiKey}`,
          'Content-Type': 'application/json',
        },
      }
    );

    const { id: sessionId, wave_launch_url } = response.data;

    await db.promise().query(
      'INSERT INTO paiements (utilisateur_id, montant, type, reference_id, methode, transaction_id) VALUES (?, ?, ?, ?, ?, ?)',
      [req.utilisateur.id, montant, type, reference_id, 'wave', sessionId]
    );

    res.json({
      message: '✅ Paiement Wave initié !',
      url_paiement: wave_launch_url,
      session_id: sessionId,
      montant,
    });
  } catch (error) {
    res.status(500).json({ message: 'Erreur Wave: ' + error.message });
  }
});

// Webhook Wave
router.post('/wave/webhook', async (req, res) => {
  const { id, payment_status, client_reference } = req.body;

  try {
    if (payment_status === 'succeeded') {
      await db.promise().query(
        'UPDATE paiements SET statut = "confirme" WHERE transaction_id = ?',
        [id]
      );

      // Extraire infos depuis client_reference : "userId_type_refId"
      const [utilisateur_id, type, reference_id] = client_reference.split('_');
      await activerAcces(utilisateur_id, type, reference_id);

      res.json({ message: '✅ Paiement Wave confirmé !' });
    } else {
      await db.promise().query(
        'UPDATE paiements SET statut = "echoue" WHERE transaction_id = ?',
        [id]
      );
      res.json({ message: 'Paiement Wave échoué.' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Erreur webhook Wave.' });
  }
});

// ═══════════════════════════════════════════
// 3️⃣  ORANGE MONEY
// ═══════════════════════════════════════════

// Obtenir le token Orange Money
async function getOrangeToken() {
  const credentials = Buffer.from(
    `${CONFIG.orangeMoney.clientId}:${CONFIG.orangeMoney.clientSecret}`
  ).toString('base64');

  const response = await axios.post(
    'https://api.orange.com/oauth/v3/token',
    'grant_type=client_credentials',
    {
      headers: {
        Authorization: `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    }
  );

  return response.data.access_token;
}

router.post('/orange/initier', verifierToken, async (req, res) => {
  const { type, reference_id, telephone } = req.body;

  if (!telephone) {
    return res.status(400).json({ message: '❌ Numéro de téléphone Orange obligatoire.' });
  }

  try {
    const { montant, description } = await getMontant(type, reference_id);
    const accessToken = await getOrangeToken();

    const orderId = `DONI_${Date.now()}_${req.utilisateur.id}`;

    const response = await axios.post(
      `${CONFIG.orangeMoney.baseUrl}/webpayment`,
      {
        merchant_key: process.env.ORANGE_MERCHANT_KEY,
        currency: 'OUV',
        order_id: orderId,
        amount: montant,
        return_url: `${process.env.FRONTEND_URL}/paiement/succes`,
        cancel_url: `${process.env.FRONTEND_URL}/paiement/annule`,
        notif_url: `${process.env.BACKEND_URL}/api/paiement/orange/callback`,
        lang: 'fr',
        reference: description,
      },
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
      }
    );

    const { payment_url, notif_token } = response.data;

    await db.promise().query(
      'INSERT INTO paiements (utilisateur_id, montant, type, reference_id, methode, transaction_id) VALUES (?, ?, ?, ?, ?, ?)',
      [req.utilisateur.id, montant, type, reference_id, 'orange_money', orderId]
    );

    res.json({
      message: '✅ Paiement Orange Money initié !',
      url_paiement: payment_url,
      order_id: orderId,
      montant,
    });
  } catch (error) {
    res.status(500).json({ message: 'Erreur Orange Money: ' + error.message });
  }
});

// Callback Orange Money
router.post('/orange/callback', async (req, res) => {
  const { order_id, status } = req.body;

  try {
    if (status === 'SUCCESS') {
      await db.promise().query(
        'UPDATE paiements SET statut = "confirme" WHERE transaction_id = ?',
        [order_id]
      );

      const [paiements] = await db.promise().query(
        'SELECT * FROM paiements WHERE transaction_id = ?',
        [order_id]
      );

      if (paiements.length > 0) {
        await activerAcces(
          paiements[0].utilisateur_id,
          paiements[0].type,
          paiements[0].reference_id
        );
      }

      res.json({ message: '✅ Paiement Orange Money confirmé !' });
    } else {
      await db.promise().query(
        'UPDATE paiements SET statut = "echoue" WHERE transaction_id = ?',
        [order_id]
      );
      res.json({ message: 'Paiement Orange Money échoué.' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Erreur callback Orange Money.' });
  }
});

// ═══════════════════════════════════════════
// ROUTES COMMUNES
// ═══════════════════════════════════════════

// Historique des paiements
router.get('/historique', verifierToken, async (req, res) => {
  try {
    const [paiements] = await db.promise().query(
      'SELECT * FROM paiements WHERE utilisateur_id = ? ORDER BY date_paiement DESC',
      [req.utilisateur.id]
    );
    res.json({ paiements });
  } catch (error) {
    res.status(500).json({ message: 'Erreur serveur.' });
  }
});

module.exports = router;
