// ═══════════════════════════════════════════
// api.js — Connexion Frontend ↔ Backend
// Doniwaralen
// ═══════════════════════════════════════════

const API_URL = 'http://votre-ip-ec2:3000/api'; // ← Remplacez par votre IP EC2

// ── UTILITAIRES ──
const token = () => localStorage.getItem('doni_token');

const headers = () => ({
  'Content-Type': 'application/json',
  ...(token() ? { Authorization: `Bearer ${token()}` } : {}),
});

const api = async (method, endpoint, body = null) => {
  try {
    const res = await fetch(`${API_URL}${endpoint}`, {
      method,
      headers: headers(),
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Erreur serveur');
    return data;
  } catch (err) {
    throw err;
  }
};

// ═══════════════════════════════════════════
// AUTH
// ═══════════════════════════════════════════

const Auth = {
  async inscrire(nom, email, telephone, mot_de_passe) {
    return await api('POST', '/auth/inscription', { nom, email, telephone, mot_de_passe });
  },

  async connecter(email, mot_de_passe) {
    const data = await api('POST', '/auth/connexion', { email, mot_de_passe });
    if (data.token) {
      localStorage.setItem('doni_token', data.token);
      localStorage.setItem('doni_user', JSON.stringify(data.utilisateur));
    }
    return data;
  },

  deconnecter() {
    localStorage.removeItem('doni_token');
    localStorage.removeItem('doni_user');
    window.location.href = 'index.html';
  },

  estConnecte() {
    return !!localStorage.getItem('doni_token');
  },

  utilisateur() {
    const u = localStorage.getItem('doni_user');
    return u ? JSON.parse(u) : null;
  },

  estAdmin() {
    const u = this.utilisateur();
    return u && u.role === 'admin';
  },
};

// ═══════════════════════════════════════════
// COURS
// ═══════════════════════════════════════════

const Cours = {
  async tous() {
    return await api('GET', '/cours');
  },

  async parCategorie(id) {
    return await api('GET', `/cours/categorie/${id}`);
  },

  async un(id) {
    return await api('GET', `/cours/${id}`);
  },

  async sInscrire(id) {
    return await api('POST', `/cours/${id}/inscription`);
  },

  async mesCours() {
    return await api('GET', '/cours/mes/cours');
  },

  async ajouter(data) {
    return await api('POST', '/cours', data);
  },
};

// ═══════════════════════════════════════════
// BIBLIOTHÈQUE
// ═══════════════════════════════════════════

const Bibliotheque = {
  async tous() {
    return await api('GET', '/bibliotheque');
  },

  async gratuits() {
    return await api('GET', '/bibliotheque/gratuits');
  },

  async payants() {
    return await api('GET', '/bibliotheque/payants');
  },

  async lectures() {
    return await api('GET', '/bibliotheque/lectures');
  },

  async ajouter(data) {
    return await api('POST', '/bibliotheque', data);
  },
};

// ═══════════════════════════════════════════
// CONTACT
// ═══════════════════════════════════════════

const Contact = {
  async envoyer(nom, email_ou_telephone, message) {
    return await api('POST', '/contact', { nom, email_ou_telephone, message });
  },

  async messages() {
    return await api('GET', '/contact');
  },
};

// ═══════════════════════════════════════════
// PAIEMENT
// ═══════════════════════════════════════════

const Paiement = {
  async paydunya(type, reference_id) {
    return await api('POST', '/paiement/paydunya/initier', { type, reference_id });
  },

  async wave(type, reference_id) {
    return await api('POST', '/paiement/wave/initier', { type, reference_id });
  },

  async orange(type, reference_id, telephone) {
    return await api('POST', '/paiement/orange/initier', { type, reference_id, telephone });
  },

  async historique() {
    return await api('GET', '/paiement/historique');
  },
};
