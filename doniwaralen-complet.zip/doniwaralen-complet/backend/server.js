const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/cours', require('./routes/cours'));
app.use('/api/bibliotheque', require('./routes/bibliotheque'));
app.use('/api/contact', require('./routes/contact'));
app.use('/api/paiement', require('./routes/paiement'));

// Route principale
app.get('/', (req, res) => {
  res.json({
    message: 'Bienvenue sur Doniwaralen API 🎓',
    status: 'OK',
    version: '1.0.0',
    routes: ['/api/auth', '/api/cours', '/api/bibliotheque', '/api/contact', '/api/paiement']
  });
});

app.listen(PORT, () => {
  console.log(`✅ Serveur Doniwaralen démarré sur le port ${PORT}`);
});
