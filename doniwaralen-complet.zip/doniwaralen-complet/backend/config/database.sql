-- =============================================
-- BASE DE DONNÉES DONIWARALEN
-- =============================================

CREATE DATABASE IF NOT EXISTS doniwaralen;
USE doniwaralen;

-- Table des utilisateurs
CREATE TABLE IF NOT EXISTS utilisateurs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(100) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  telephone VARCHAR(20),
  mot_de_passe VARCHAR(255) NOT NULL,
  role ENUM('etudiant', 'admin') DEFAULT 'etudiant',
  actif BOOLEAN DEFAULT TRUE,
  date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des catégories de cours
CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(100) NOT NULL,
  description TEXT,
  icone VARCHAR(10)
);

-- Insérer les catégories
INSERT INTO categories (nom, description, icone) VALUES
('Cours en Langue', 'Français, Anglais, Bambara et autres langues', '🌐'),
('Cours en Informatique', 'Programmation, Réseaux, Cloud, Bureautique', '💻'),
('Cours Divers', 'Entrepreneuriat, Santé, Agriculture, Développement personnel', '📚');

-- Table des cours
CREATE TABLE IF NOT EXISTS cours (
  id INT AUTO_INCREMENT PRIMARY KEY,
  titre VARCHAR(200) NOT NULL,
  description TEXT,
  categorie_id INT,
  prix DECIMAL(10,2) DEFAULT 0.00,
  gratuit BOOLEAN DEFAULT FALSE,
  niveau ENUM('debutant', 'intermediaire', 'avance') DEFAULT 'debutant',
  image_url VARCHAR(255),
  actif BOOLEAN DEFAULT TRUE,
  date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (categorie_id) REFERENCES categories(id)
);

-- Table des livres (bibliothèque)
CREATE TABLE IF NOT EXISTS livres (
  id INT AUTO_INCREMENT PRIMARY KEY,
  titre VARCHAR(200) NOT NULL,
  auteur VARCHAR(150),
  description TEXT,
  type ENUM('gratuit', 'payant', 'lecture_en_ligne') NOT NULL,
  prix DECIMAL(10,2) DEFAULT 0.00,
  fichier_url VARCHAR(255),
  image_url VARCHAR(255),
  actif BOOLEAN DEFAULT TRUE,
  date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des inscriptions aux cours
CREATE TABLE IF NOT EXISTS inscriptions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  utilisateur_id INT,
  cours_id INT,
  date_inscription TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  statut ENUM('actif', 'termine', 'annule') DEFAULT 'actif',
  FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id),
  FOREIGN KEY (cours_id) REFERENCES cours(id)
);

-- Table des paiements
CREATE TABLE IF NOT EXISTS paiements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  utilisateur_id INT,
  montant DECIMAL(10,2) NOT NULL,
  type ENUM('cours', 'livre', 'lecture') NOT NULL,
  reference_id INT,
  methode ENUM('orange_money', 'wave', 'paydunya') NOT NULL,
  statut ENUM('en_attente', 'confirme', 'echoue') DEFAULT 'en_attente',
  transaction_id VARCHAR(100),
  date_paiement TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id)
);

-- Table des messages de contact
CREATE TABLE IF NOT EXISTS contacts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(100) NOT NULL,
  email_ou_telephone VARCHAR(150) NOT NULL,
  message TEXT NOT NULL,
  lu BOOLEAN DEFAULT FALSE,
  date_envoi TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Données de test
INSERT INTO cours (titre, description, categorie_id, prix, gratuit, niveau) VALUES
('Français débutant', 'Apprenez le français de zéro', 1, 0, TRUE, 'debutant'),
('Anglais intermédiaire', 'Améliorez votre anglais', 1, 5000, FALSE, 'intermediaire'),
('Introduction à Python', 'Programmez avec Python', 2, 0, TRUE, 'debutant'),
('AWS Cloud Practitioner', 'Maîtrisez le cloud AWS', 2, 10000, FALSE, 'intermediaire'),
('Entrepreneuriat au Mali', 'Créez votre entreprise', 3, 0, TRUE, 'debutant');

INSERT INTO livres (titre, auteur, description, type, prix) VALUES
('Guide du développeur web', 'Doniwaralen', 'HTML, CSS, JavaScript complet', 'gratuit', 0),
('Python pour débutants', 'Doniwaralen', 'Apprenez Python étape par étape', 'payant', 3000),
('Réussir en Afrique', 'Mamadou Koné', 'Guide entrepreneuriat africain', 'lecture_en_ligne', 2000);
