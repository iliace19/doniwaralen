const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { verifierToken, verifierAdmin } = require('../middleware/auth');

// ── ENVOYER UN MESSAGE ──
router.post('/', (req, res) => {
  const { nom, email_ou_telephone, message } = req.body;

  if (!nom || !email_ou_telephone || !message) {
    return res.status(400).json({ message: '❌ Tous les champs sont obligatoires.' });
  }

  db.query(
    'INSERT INTO contacts (nom, email_ou_telephone, message) VALUES (?, ?, ?)',
    [nom, email_ou_telephone, message],
    (err, result) => {
      if (err) return res.status(500).json({ message: 'Erreur lors de l\'envoi.' });
      res.status(201).json({ message: '✅ Message envoyé avec succès ! Nous vous répondrons bientôt.' });
    }
  );
});

// ── VOIR TOUS LES MESSAGES (Admin) ──
router.get('/', verifierToken, verifierAdmin, (req, res) => {
  db.query(
    'SELECT * FROM contacts ORDER BY date_envoi DESC',
    (err, results) => {
      if (err) return res.status(500).json({ message: 'Erreur serveur.' });
      res.json({ messages: results, total: results.length });
    }
  );
});

// ── MARQUER COMME LU (Admin) ──
router.put('/:id/lu', verifierToken, verifierAdmin, (req, res) => {
  db.query(
    'UPDATE contacts SET lu = TRUE WHERE id = ?',
    [req.params.id],
    (err) => {
      if (err) return res.status(500).json({ message: 'Erreur serveur.' });
      res.json({ message: '✅ Message marqué comme lu.' });
    }
  );
});

module.exports = router;
