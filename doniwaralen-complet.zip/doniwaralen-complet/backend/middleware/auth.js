const jwt = require('jsonwebtoken');

const verifierToken = (req, res, next) => {
  const token = req.headers['authorization'];

  if (!token) {
    return res.status(401).json({ message: '❌ Accès refusé. Token manquant.' });
  }

  try {
    const tokenPropre = token.startsWith('Bearer ') ? token.slice(7) : token;
    const decoded = jwt.verify(tokenPropre, process.env.JWT_SECRET);
    req.utilisateur = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ message: '❌ Token invalide ou expiré.' });
  }
};

const verifierAdmin = (req, res, next) => {
  if (req.utilisateur.role !== 'admin') {
    return res.status(403).json({ message: '❌ Accès réservé aux administrateurs.' });
  }
  next();
};

module.exports = { verifierToken, verifierAdmin };
