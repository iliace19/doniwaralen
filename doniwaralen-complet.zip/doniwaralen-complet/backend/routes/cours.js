const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { verifierToken, verifierAdmin } = require('../middleware/auth');

// ── TOUS LES COURS ──
router.get('/', (req, res) => {
  const sql = `
    SELECT c.*, cat.nom AS categorie_nom, cat.icone
    FROM cours c
    JOIN categories cat ON c.categorie_id = cat.id
    WHERE c.actif = TRUE
    ORDER BY c.date_creation DESC
  `;
  db.query(sql, (err, results) => {
    if (err) return res.status(500).json({ message: 'Erreur serveur.' });
    res.json({ cours: results });
  });
});

// ── COURS PAR CATÉGORIE ──
router.get('/categorie/:id', (req, res) => {
  const sql = `
    SELECT c.*, cat.nom AS categorie_nom
    FROM cours c
    JOIN categories cat ON c.categorie_id = cat.id
    WHERE c.categorie_id = ? AND c.actif = TRUE
  `;
  db.query(sql, [req.params.id], (err, results) => {
    if (err) return res.status(500).json({ message: 'Erreur serveur.' });
    res.json({ cours: results });
  });
});

// ── UN COURS SPÉCIFIQUE ──
router.get('/:id', (req, res) => {
  const sql = `
    SELECT c.*, cat.nom AS categorie_nom
    FROM cours c
    JOIN categories cat ON c.categorie_id = cat.id
    WHERE c.id = ? AND c.actif = TRUE
  `;
  db.query(sql, [req.params.id], (err, results) => {
    if (err) return res.status(500).json({ message: 'Erreur serveur.' });
    if (results.length === 0) return res.status(404).json({ message: 'Cours introuvable.' });
    res.json({ cours: results[0] });
  });
});

// ── CRÉER UN COURS (Admin) ──
router.post('/', verifierToken, verifierAdmin, (req, res) => {
  const { titre, description, categorie_id, prix, gratuit, niveau, image_url } = req.body;

  if (!titre || !categorie_id) {
    return res.status(400).json({ message: '❌ Titre et catégorie sont obligatoires.' });
  }

  db.query(
    'INSERT INTO cours (titre, description, categorie_id, prix, gratuit, niveau, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [titre, description, categorie_id, prix || 0, gratuit || false, niveau || 'debutant', image_url],
    (err, result) => {
      if (err) return res.status(500).json({ message: 'Erreur lors de la création.' });
      res.status(201).json({ message: '✅ Cours créé avec succès !', id: result.insertId });
    }
  );
});

// ── S'INSCRIRE À UN COURS ──
router.post('/:id/inscription', verifierToken, (req, res) => {
  const utilisateur_id = req.utilisateur.id;
  const cours_id = req.params.id;

  // Vérifier si déjà inscrit
  db.query(
    'SELECT id FROM inscriptions WHERE utilisateur_id = ? AND cours_id = ?',
    [utilisateur_id, cours_id],
    (err, results) => {
      if (err) return res.status(500).json({ message: 'Erreur serveur.' });
      if (results.length > 0) {
        return res.status(400).json({ message: '❌ Vous êtes déjà inscrit à ce cours.' });
      }

      db.query(
        'INSERT INTO inscriptions (utilisateur_id, cours_id) VALUES (?, ?)',
        [utilisateur_id, cours_id],
        (err) => {
          if (err) return res.status(500).json({ message: 'Erreur inscription.' });
          res.json({ message: '✅ Inscription réussie !' });
        }
      );
    }
  );
});

// ── MES COURS ──
router.get('/mes/cours', verifierToken, (req, res) => {
  const sql = `
    SELECT c.*, i.date_inscription, i.statut
    FROM cours c
    JOIN inscriptions i ON c.id = i.cours_id
    WHERE i.utilisateur_id = ?
  `;
  db.query(sql, [req.utilisateur.id], (err, results) => {
    if (err) return res.status(500).json({ message: 'Erreur serveur.' });
    res.json({ cours: results });
  });
});

module.exports = router;
