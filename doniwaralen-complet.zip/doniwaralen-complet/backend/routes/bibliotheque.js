const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { verifierToken, verifierAdmin } = require('../middleware/auth');

// ── TOUS LES LIVRES ──
router.get('/', (req, res) => {
  db.query(
    'SELECT * FROM livres WHERE actif = TRUE ORDER BY date_creation DESC',
    (err, results) => {
      if (err) return res.status(500).json({ message: 'Erreur serveur.' });
      res.json({ livres: results });
    }
  );
});

// ── LIVRES GRATUITS ──
router.get('/gratuits', (req, res) => {
  db.query(
    'SELECT * FROM livres WHERE type = "gratuit" AND actif = TRUE',
    (err, results) => {
      if (err) return res.status(500).json({ message: 'Erreur serveur.' });
      res.json({ livres: results });
    }
  );
});

// ── LIVRES PAYANTS ──
router.get('/payants', (req, res) => {
  db.query(
    'SELECT * FROM livres WHERE type = "payant" AND actif = TRUE',
    (err, results) => {
      if (err) return res.status(500).json({ message: 'Erreur serveur.' });
      res.json({ livres: results });
    }
  );
});

// ── LECTURES EN LIGNE ──
router.get('/lectures', (req, res) => {
  db.query(
    'SELECT * FROM livres WHERE type = "lecture_en_ligne" AND actif = TRUE',
    (err, results) => {
      if (err) return res.status(500).json({ message: 'Erreur serveur.' });
      res.json({ livres: results });
    }
  );
});

// ── UN LIVRE SPÉCIFIQUE ──
router.get('/:id', (req, res) => {
  db.query(
    'SELECT * FROM livres WHERE id = ? AND actif = TRUE',
    [req.params.id],
    (err, results) => {
      if (err) return res.status(500).json({ message: 'Erreur serveur.' });
      if (results.length === 0) return res.status(404).json({ message: 'Livre introuvable.' });
      res.json({ livre: results[0] });
    }
  );
});

// ── AJOUTER UN LIVRE (Admin) ──
router.post('/', verifierToken, verifierAdmin, (req, res) => {
  const { titre, auteur, description, type, prix, fichier_url, image_url } = req.body;

  if (!titre || !type) {
    return res.status(400).json({ message: '❌ Titre et type sont obligatoires.' });
  }

  db.query(
    'INSERT INTO livres (titre, auteur, description, type, prix, fichier_url, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [titre, auteur, description, type, prix || 0, fichier_url, image_url],
    (err, result) => {
      if (err) return res.status(500).json({ message: 'Erreur lors de l\'ajout.' });
      res.status(201).json({ message: '✅ Livre ajouté avec succès !', id: result.insertId });
    }
  );
});

module.exports = router;
