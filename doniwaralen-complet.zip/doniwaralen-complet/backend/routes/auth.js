const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db');

// ── INSCRIPTION ──
router.post('/inscription', (req, res) => {
  const { nom, email, telephone, mot_de_passe } = req.body;

  if (!nom || !email || !mot_de_passe) {
    return res.status(400).json({ message: '❌ Nom, email et mot de passe sont obligatoires.' });
  }

  // Vérifier si l'email existe déjà
  db.query('SELECT id FROM utilisateurs WHERE email = ?', [email], (err, results) => {
    if (err) return res.status(500).json({ message: 'Erreur serveur.' });
    if (results.length > 0) {
      return res.status(400).json({ message: '❌ Cet email est déjà utilisé.' });
    }

    // Chiffrer le mot de passe
    const hash = bcrypt.hashSync(mot_de_passe, 10);

    db.query(
      'INSERT INTO utilisateurs (nom, email, telephone, mot_de_passe) VALUES (?, ?, ?, ?)',
      [nom, email, telephone, hash],
      (err, result) => {
        if (err) return res.status(500).json({ message: 'Erreur lors de l\'inscription.' });
        res.status(201).json({ message: '✅ Inscription réussie !', id: result.insertId });
      }
    );
  });
});

// ── CONNEXION ──
router.post('/connexion', (req, res) => {
  const { email, mot_de_passe } = req.body;

  if (!email || !mot_de_passe) {
    return res.status(400).json({ message: '❌ Email et mot de passe obligatoires.' });
  }

  db.query('SELECT * FROM utilisateurs WHERE email = ? AND actif = TRUE', [email], (err, results) => {
    if (err) return res.status(500).json({ message: 'Erreur serveur.' });
    if (results.length === 0) {
      return res.status(401).json({ message: '❌ Email ou mot de passe incorrect.' });
    }

    const utilisateur = results[0];
    const motDePasseValide = bcrypt.compareSync(mot_de_passe, utilisateur.mot_de_passe);

    if (!motDePasseValide) {
      return res.status(401).json({ message: '❌ Email ou mot de passe incorrect.' });
    }

    const token = jwt.sign(
      { id: utilisateur.id, email: utilisateur.email, role: utilisateur.role },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      message: '✅ Connexion réussie !',
      token,
      utilisateur: {
        id: utilisateur.id,
        nom: utilisateur.nom,
        email: utilisateur.email,
        role: utilisateur.role
      }
    });
  });
});

module.exports = router;
