# 🎓 Doniwaralen — Plateforme Éducative Complète
## Bamako, Mali 🇲🇱

---

## 📁 Structure du projet

```
doniwaralen-complet/
├── frontend/
│   ├── index.html      ← Page d'accueil connectée
│   ├── admin.html      ← Tableau de bord admin
│   └── api.js          ← Connexion API backend
│
└── backend/
    ├── server.js       ← Point d'entrée serveur
    ├── package.json    ← Dépendances
    ├── .env.example    ← Configuration (à copier en .env)
    ├── config/
    │   ├── db.js       ← Connexion MySQL
    │   └── database.sql← Schéma base de données
    ├── middleware/
    │   └── auth.js     ← Vérification JWT
    └── routes/
        ├── auth.js        ← Inscription / Connexion
        ├── cours.js       ← Gestion des cours
        ├── bibliotheque.js← Gestion des livres
        ├── contact.js     ← Messages de contact
        └── paiement.js    ← Orange Money + Wave + PayDunya
```

---

## 🚀 Installation sur EC2

### 1. Connexion SSH
```bash
ssh -i "ma-cle.pem" ec2-user@<VOTRE-IP-EC2>
```

### 2. Installer Node.js et MySQL
```bash
# Node.js
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo yum install -y nodejs

# MySQL
sudo yum install -y mysql-server
sudo systemctl start mysqld
sudo systemctl enable mysqld
```

### 3. Déployer le backend
```bash
# Uploader les fichiers
scp -i "ma-cle.pem" -r backend/* ec2-user@<IP>:~/doniwaralen/

# Sur EC2
cd ~/doniwaralen
npm install
cp .env.example .env
nano .env  # Remplir vos vraies valeurs
```

### 4. Créer la base de données
```bash
mysql -u root -p < config/database.sql
```

### 5. Démarrer le serveur
```bash
npm start
# ou en production avec PM2 :
npm install -g pm2
pm2 start server.js --name doniwaralen
pm2 save
```

### 6. Déployer le frontend
```bash
# Modifier l'URL API dans api.js
# const API_URL = 'http://VOTRE-IP-EC2:3000/api';

scp -i "ma-cle.pem" -r frontend/* ec2-user@<IP>:/usr/share/nginx/html/
```

---

## 📡 API Endpoints

| Route | Description |
|-------|-------------|
| POST /api/auth/inscription | Créer un compte |
| POST /api/auth/connexion | Se connecter |
| GET /api/cours | Tous les cours |
| GET /api/bibliotheque | Tous les livres |
| POST /api/contact | Envoyer un message |
| POST /api/paiement/paydunya/initier | Payer avec PayDunya |
| POST /api/paiement/wave/initier | Payer avec Wave |
| POST /api/paiement/orange/initier | Payer avec Orange Money |

---

## 💳 Paiement — Comptes à créer

1. **PayDunya** → https://paydunya.com
2. **Wave** → https://www.wave.com/fr/developers/
3. **Orange Money** → https://developer.orange.com

---

## ✅ Fonctionnalités

- 🔐 Authentification JWT (inscription/connexion)
- 📚 Cours par catégorie (Langues, Informatique, Divers)
- 📖 Bibliothèque (Gratuit, Payant, Lecture en ligne)
- 💳 Paiement Orange Money + Wave + PayDunya
- ✉️ Formulaire de contact
- 👨‍💼 Tableau de bord admin complet
